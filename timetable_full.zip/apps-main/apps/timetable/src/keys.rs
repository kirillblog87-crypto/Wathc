//! The on-watch keyboard's layout and the typed text. Pure code, host-tested.
//! The keys show capital letters; the text gets a capital after a space or at the start and small letters elsewhere.

pub const NAME_MAX: usize = 30;

/// Keys per row, top to bottom: 33 letters.
pub const ROW_LEN: [usize; 4] = [9, 8, 8, 8];
pub const KEYS: usize = 33;

/// Flat key index -> label, letters.
pub const LETTERS: [&str; KEYS] = [
    "Й", "Ц", "У", "К", "Е", "Н", "Г", "Ш", "Щ", //
    "З", "Х", "Ъ", "Ф", "Ы", "В", "А", "П", //
    "Р", "О", "Л", "Д", "Ж", "Э", "Я", "Ч", //
    "С", "М", "И", "Т", "Ь", "Б", "Ю", "Ё",
];

/// Digits and a few marks; an empty label is a key that does nothing in this mode.
pub const SYMBOLS: [&str; KEYS] = [
    "1", "2", "3", "4", "5", "6", "7", "8", "9", //
    "0", "-", ".", ",", "(", ")", "/", "+", //
    "", "", "", "", "", "", "", "", //
    "", "", "", "", "", "", "", "",
];

pub fn label(digits: bool, key: usize) -> &'static str {
    if digits { SYMBOLS[key.min(KEYS - 1)] } else { LETTERS[key.min(KEYS - 1)] }
}

/// Typed text, at most [`NAME_MAX`] bytes of valid UTF-8.
#[derive(Clone, Copy)]
pub struct Text {
    buf: [u8; NAME_MAX],
    len: usize,
}

impl Text {
    pub const fn new() -> Self {
        Text { buf: [0; NAME_MAX], len: 0 }
    }

    pub fn as_str(&self) -> &str {
        core::str::from_utf8(&self.buf[..self.len]).unwrap_or("")
    }

    /// Replaces the text, cutting it at a character boundary if it is too long.
    pub fn set(&mut self, s: &str) {
        self.len = 0;
        for (i, c) in s.char_indices() {
            if i + c.len_utf8() > NAME_MAX {
                break;
            }
            self.len = i + c.len_utf8();
        }
        self.buf[..self.len].copy_from_slice(&s.as_bytes()[..self.len]);
    }

    fn push_bytes(&mut self, b: &[u8]) -> bool {
        if self.len + b.len() > NAME_MAX {
            return false;
        }
        self.buf[self.len..self.len + b.len()].copy_from_slice(b);
        self.len += b.len();
        true
    }

    /// A key press (a label from `LETTERS` or `SYMBOLS`). Letters become small unless they start a word.
    pub fn press(&mut self, key: &str) -> bool {
        let b = key.as_bytes();
        let word_start = self.len == 0 || self.buf[self.len - 1] == b' ';
        if b.len() == 2 && !word_start {
            return self.push_bytes(&lower(b));
        }
        self.push_bytes(b)
    }

    pub fn space(&mut self) -> bool {
        if self.len == 0 || self.buf[self.len - 1] == b' ' {
            return false;
        }
        self.push_bytes(b" ")
    }

    /// Removes the last character.
    pub fn backspace(&mut self) -> bool {
        if self.len == 0 {
            return false;
        }
        self.len -= 1;
        while self.len > 0 && self.buf[self.len] & 0xC0 == 0x80 {
            self.len -= 1;
        }
        true
    }
}

/// Capital Cyrillic (two UTF-8 bytes) to small. Anything else is returned unchanged.
fn lower(b: &[u8]) -> [u8; 2] {
    match (b[0], b[1]) {
        (0xD0, 0x81) => [0xD1, 0x91],
        (0xD0, x @ 0x90..=0x9F) => [0xD0, x + 0x20],
        (0xD0, x @ 0xA0..=0xAF) => [0xD1, x - 0x20],
        _ => [b[0], b[1]],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn layout_has_33_letters_in_four_rows() {
        assert_eq!(ROW_LEN.iter().sum::<usize>(), KEYS);
        assert!(LETTERS.iter().all(|l| l.chars().count() == 1));
    }

    #[test]
    fn a_word_gets_one_capital() {
        let mut t = Text::new();
        for k in ["М", "А", "Т", "Е", "М", "А", "Т", "И", "К", "А"] {
            t.press(k);
        }
        assert_eq!(t.as_str(), "Математика");
        t.space();
        t.space();
        t.press("Ё");
        assert_eq!(t.as_str(), "Математика Ё");
        t.press("Ё");
        assert_eq!(t.as_str(), "Математика Ёё");
    }

    #[test]
    fn every_letter_lowercases_like_unicode() {
        for k in LETTERS {
            let mut t = Text::new();
            t.press("А");
            t.press(k);
            let want: std::string::String = k.to_lowercase();
            assert_eq!(&t.as_str()[2..], want);
        }
    }

    #[test]
    fn backspace_removes_whole_characters_and_the_text_is_bounded() {
        let mut t = Text::new();
        t.press("Я");
        t.press("Ч");
        assert!(t.backspace());
        assert_eq!(t.as_str(), "Я");
        for _ in 0..40 {
            t.press("Ы");
        }
        assert!(t.as_str().len() <= NAME_MAX);
        assert!(core::str::from_utf8(t.as_str().as_bytes()).is_ok());
        let mut e = Text::new();
        assert!(!e.backspace());
        e.set("Физика");
        assert_eq!(e.as_str(), "Физика");
    }
}
