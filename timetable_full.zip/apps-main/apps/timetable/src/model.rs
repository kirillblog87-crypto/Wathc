//! Timetable data and time arithmetic. Pure code, no SDK calls: host-tested (`make test APP=timetable`).
//! No heap: lessons live in fixed arrays, text is formatted into caller buffers.

use crate::keys::Text;

pub const MAX_LESSONS: usize = 12;
pub use crate::keys::NAME_MAX;
/// Minutes are chosen in steps of 5.
pub const STEP: u16 = 5;
const LAST_START: u16 = 23 * 60 + 55;

pub const BLOB_MAGIC: [u8; 2] = *b"TT";
pub const BLOB_VERSION: u8 = 1;
const LESSON_BYTES: usize = 2 + 2 + 1 + NAME_MAX;
/// magic, version, count, then the lessons: 4 + 12 * 35 = 424 B of the 4096 B storage.
pub const BLOB_MAX: usize = 4 + MAX_LESSONS * LESSON_BYTES;

#[derive(Clone, Copy)]
pub struct Lesson {
    /// Minutes since midnight.
    pub start: u16,
    pub end: u16,
    name: Text,
}

impl Lesson {
    pub fn new(start: u16, end: u16, name: Text) -> Self {
        Lesson { start, end, name }
    }
    pub fn name(&self) -> &str {
        self.name.as_str()
    }
}

#[derive(Clone, Copy)]
pub struct Schedule {
    lessons: [Lesson; MAX_LESSONS],
    len: usize,
}

/// What the clock says about the schedule right now.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Now {
    Empty,
    /// In lesson `idx`: seconds left and the lesson's length in seconds.
    Lesson { idx: usize, left_s: u32, total_s: u32 },
    /// Between lessons (or before the first): lesson `idx` is next, in `left_s` seconds.
    Break { idx: usize, left_s: u32 },
    Over,
}

impl Schedule {
    pub fn new() -> Self {
        Schedule { lessons: [Lesson::new(0, 0, Text::new()); MAX_LESSONS], len: 0 }
    }
    pub fn len(&self) -> usize {
        self.len
    }
    pub fn get(&self, i: usize) -> &Lesson {
        &self.lessons[i.min(MAX_LESSONS - 1)]
    }

    /// Adds or replaces (`idx < len`) a lesson, then keeps the list sorted by start. False when full.
    pub fn put(&mut self, idx: usize, lesson: Lesson) -> bool {
        if idx < self.len {
            self.lessons[idx] = lesson;
        } else if self.len < MAX_LESSONS {
            self.lessons[self.len] = lesson;
            self.len += 1;
        } else {
            return false;
        }
        self.sort();
        true
    }

    pub fn remove(&mut self, idx: usize) {
        if idx >= self.len {
            return;
        }
        for i in idx..self.len - 1 {
            self.lessons[i] = self.lessons[i + 1];
        }
        self.len -= 1;
    }

    fn sort(&mut self) {
        // insertion sort: at most 12 items
        for i in 1..self.len {
            let mut j = i;
            while j > 0 && self.lessons[j - 1].start > self.lessons[j].start {
                self.lessons.swap(j - 1, j);
                j -= 1;
            }
        }
    }

    /// Where a new lesson starts by default: 10 minutes after the last one, 08:30 for the first.
    pub fn next_start(&self) -> u16 {
        if self.len == 0 {
            return 8 * 60 + 30;
        }
        let last = self.lessons[self.len - 1].end;
        (last + 10).min(LAST_START) / STEP * STEP
    }

    pub fn status(&self, now_s: u32) -> Now {
        if self.len == 0 {
            return Now::Empty;
        }
        for i in 0..self.len {
            let (s, e) = (self.lessons[i].start as u32 * 60, self.lessons[i].end as u32 * 60);
            if now_s < s {
                return Now::Break { idx: i, left_s: s - now_s };
            }
            if now_s < e {
                return Now::Lesson { idx: i, left_s: e - now_s, total_s: e - s };
            }
        }
        Now::Over
    }

    /// Writes the blob for `Api::save`; returns its length.
    pub fn encode(&self, out: &mut [u8; BLOB_MAX]) -> usize {
        out[0..2].copy_from_slice(&BLOB_MAGIC);
        out[2] = BLOB_VERSION;
        out[3] = self.len as u8;
        let mut p = 4;
        for l in &self.lessons[..self.len] {
            out[p..p + 2].copy_from_slice(&l.start.to_le_bytes());
            out[p + 2..p + 4].copy_from_slice(&l.end.to_le_bytes());
            let n = l.name.as_str().as_bytes();
            out[p + 4] = n.len() as u8;
            out[p + 5..p + 5 + NAME_MAX].fill(0);
            out[p + 5..p + 5 + n.len()].copy_from_slice(n);
            p += LESSON_BYTES;
        }
        p
    }

    /// Reads a blob; anything unexpected is "never saved" (an empty schedule).
    pub fn decode(blob: &[u8]) -> Self {
        let mut s = Schedule::new();
        if blob.len() < 4 || blob[0..2] != BLOB_MAGIC || blob[2] != BLOB_VERSION {
            return s;
        }
        let n = (blob[3] as usize).min(MAX_LESSONS);
        if blob.len() < 4 + n * LESSON_BYTES {
            return s;
        }
        for i in 0..n {
            let p = 4 + i * LESSON_BYTES;
            let start = u16::from_le_bytes([blob[p], blob[p + 1]]);
            let end = u16::from_le_bytes([blob[p + 2], blob[p + 3]]);
            let len = (blob[p + 4] as usize).min(NAME_MAX);
            let mut name = Text::new();
            name.set(core::str::from_utf8(&blob[p + 5..p + 5 + len]).unwrap_or(""));
            if start < end && end <= 24 * 60 {
                s.lessons[s.len] = Lesson::new(start, end, name);
                s.len += 1;
            }
        }
        s.sort();
        s
    }
}

/// A lesson being edited. Hours and minute steps are what the rollers show.
#[derive(Clone, Copy)]
pub struct Edit {
    /// `idx >= schedule.len()`: a new lesson.
    pub idx: usize,
    pub sh: u8,
    pub sm: u8,
    pub eh: u8,
    pub em: u8,
    pub name: Text,
}

impl Edit {
    pub fn from_lesson(idx: usize, l: &Lesson) -> Self {
        Edit { idx, sh: (l.start / 60) as u8, sm: (l.start % 60 / STEP) as u8, eh: (l.end / 60) as u8,
               em: (l.end % 60 / STEP) as u8, name: l.name }
    }
    pub fn new_lesson(sch: &Schedule) -> Self {
        let start = sch.next_start();
        let end = (start + 40).min(23 * 60 + 55);
        Edit::from_lesson(sch.len(), &Lesson::new(start, end, Text::new()))
    }
    pub fn start(&self) -> u16 {
        self.sh as u16 * 60 + self.sm as u16 * STEP
    }
    pub fn end(&self) -> u16 {
        self.eh as u16 * 60 + self.em as u16 * STEP
    }
    /// The lesson to store. An end that is not after the start becomes start + 40 minutes.
    pub fn to_lesson(&self) -> Lesson {
        let start = self.start();
        let mut end = self.end();
        if end <= start {
            end = (start + 40).min(24 * 60);
        }
        Lesson::new(start, end, self.name)
    }
}

fn put_str(buf: &mut [u8], at: usize, s: &str) -> usize {
    let b = s.as_bytes();
    buf[at..at + b.len()].copy_from_slice(b);
    at + b.len()
}

fn two(buf: &mut [u8], at: usize, v: u32) {
    buf[at] = b'0' + (v / 10 % 10) as u8;
    buf[at + 1] = b'0' + (v % 10) as u8;
}

fn as_str(buf: &[u8]) -> &str {
    core::str::from_utf8(buf).unwrap_or("")
}

/// `HH:MM` from minutes since midnight.
pub fn hhmm(min: u16, buf: &mut [u8; 5]) -> &str {
    two(buf, 0, (min / 60) as u32);
    buf[2] = b':';
    two(buf, 3, (min % 60) as u32);
    as_str(buf)
}

/// `HH:MM-HH:MM`.
pub fn range(a: u16, b: u16, buf: &mut [u8; 11]) -> &str {
    two(buf, 0, (a / 60) as u32);
    buf[2] = b':';
    two(buf, 3, (a % 60) as u32);
    buf[5] = b'-';
    two(buf, 6, (b / 60) as u32);
    buf[8] = b':';
    two(buf, 9, (b % 60) as u32);
    as_str(buf)
}

/// `1`..`99`.
pub fn number(n: usize, buf: &mut [u8; 3]) -> &str {
    let n = n.clamp(0, 99) as u32;
    if n < 10 {
        buf[0] = b'0' + n as u8;
        as_str(&buf[..1])
    } else {
        two(buf, 0, n);
        as_str(&buf[..2])
    }
}

/// The lesson's name, or "Предмет N" while it has none.
pub fn display_name<'a>(l: &'a Lesson, i: usize, buf: &'a mut [u8; 40]) -> &'a str {
    if !l.name().is_empty() {
        return l.name();
    }
    let mut p = put_str(buf, 0, "Предмет ");
    let mut n = [0u8; 3];
    p = put_str(buf, p, number(i + 1, &mut n));
    as_str(&buf[..p])
}

/// `MM:SS`, or `H:MM:SS` from one hour.
pub fn countdown(secs: u32, buf: &mut [u8; 8]) -> &str {
    let (h, m, s) = (secs / 3600, secs / 60 % 60, secs % 60);
    if h == 0 {
        two(buf, 0, m);
        buf[2] = b':';
        two(buf, 3, s);
        as_str(&buf[..5])
    } else {
        buf[0] = b'0' + (h % 10) as u8;
        buf[1] = b':';
        two(buf, 2, m);
        buf[4] = b':';
        two(buf, 5, s);
        as_str(&buf[..7])
    }
}

/// `<name> - до HH:MM` (`prefix` "до") or `<name> - в HH:MM`.
pub fn line<'a>(name: &str, prefix: &str, min: u16, buf: &'a mut [u8; 64]) -> &'a str {
    let mut p = put_str(buf, 0, name);
    p = put_str(buf, p, " - ");
    p = put_str(buf, p, prefix);
    buf[p] = b' ';
    p += 1;
    let mut t = [0u8; 5];
    p = put_str(buf, p, hhmm(min, &mut t));
    as_str(&buf[..p])
}

/// `СЕЙЧАС HH:MM`.
pub fn clock(min: u16, buf: &mut [u8; 24]) -> &str {
    let mut p = put_str(buf, 0, "СЕЙЧАС ");
    let mut t = [0u8; 5];
    p = put_str(buf, p, hhmm(min, &mut t));
    as_str(&buf[..p])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lesson(s: u16, e: u16, name: &str) -> Lesson {
        let mut t = Text::new();
        t.set(name);
        Lesson::new(s, e, t)
    }

    #[test]
    fn status_walks_through_the_day() {
        let mut s = Schedule::new();
        assert_eq!(s.status(0), Now::Empty);
        s.put(0, lesson(9 * 60, 9 * 60 + 40, "A"));
        s.put(1, lesson(9 * 60 + 50, 10 * 60 + 30, "B"));
        assert_eq!(s.status(8 * 3600), Now::Break { idx: 0, left_s: 3600 });
        assert_eq!(s.status(9 * 3600 + 600), Now::Lesson { idx: 0, left_s: 1800, total_s: 2400 });
        assert_eq!(s.status(9 * 3600 + 2400), Now::Break { idx: 1, left_s: 600 });
        assert_eq!(s.status(11 * 3600), Now::Over);
    }

    #[test]
    fn put_sorts_and_remove_closes_the_gap() {
        let mut s = Schedule::new();
        s.put(0, lesson(600, 640, "late"));
        s.put(1, lesson(500, 540, "early"));
        assert_eq!(s.get(0).name(), "early");
        s.remove(0);
        assert_eq!((s.len(), s.get(0).name()), (1, "late"));
    }

    #[test]
    fn blob_round_trips_cyrillic_names() {
        let mut s = Schedule::new();
        s.put(0, lesson(510, 550, "Математика"));
        s.put(1, lesson(560, 600, ""));
        let mut blob = [0u8; BLOB_MAX];
        let n = s.encode(&mut blob);
        let d = Schedule::decode(&blob[..n]);
        assert_eq!(d.len(), 2);
        assert_eq!(d.get(0).name(), "Математика");
        assert_eq!((d.get(1).start, d.get(1).end), (560, 600));
        assert_eq!(Schedule::decode(b"xx").len(), 0);
    }

    #[test]
    fn formatting() {
        let (mut a, mut b, mut c) = ([0u8; 5], [0u8; 11], [0u8; 8]);
        assert_eq!(hhmm(9 * 60 + 5, &mut a), "09:05");
        assert_eq!(range(585, 625, &mut b), "09:45-10:25");
        assert_eq!(countdown(75, &mut c), "01:15");
        assert_eq!(countdown(3725, &mut c), "1:02:05");
        let l = lesson(0, 1, "");
        let mut n = [0u8; 40];
        assert_eq!(display_name(&l, 2, &mut n), "Предмет 3");
    }

    #[test]
    fn new_lesson_starts_after_the_last_and_end_is_after_start() {
        let mut s = Schedule::new();
        assert_eq!(s.next_start(), 8 * 60 + 30);
        s.put(0, lesson(510, 550, "A"));
        assert_eq!(s.next_start(), 560);
        let mut e = Edit::new_lesson(&s);
        e.eh = e.sh;
        e.em = e.sm;
        let l = e.to_lesson();
        assert!(l.end > l.start);
    }
}
